package ru.job4j.calculator;

public class Out {
    public static void main(String[]args) {
       String idea = "I like Java ";
       System.out.println(idea);
       System.out.println(idea + "'But l am a newbie.'");
       int year = 2021;
       idea = idea + year;
       System.out.println(idea + idea);
      }
}