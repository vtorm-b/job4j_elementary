package ru.job4j.loop;
/*
public class SecondSum {
    public static int sum(int a, int b) {
        for (int a = 0; a < b ; a++) {

        }{

            }
    }
    public static void main(String[]args) {
        sum(1,2);
        System.out.print();
    }

}
*/